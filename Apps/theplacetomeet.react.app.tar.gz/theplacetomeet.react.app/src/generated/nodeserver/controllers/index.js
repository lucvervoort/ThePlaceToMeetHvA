const CateringController = require('./CateringController');
const CustomerController = require('./CustomerController');
const MeetingRoomController = require('./MeetingRoomController');

module.exports = {
  CateringController,
  CustomerController,
  MeetingRoomController,
};
