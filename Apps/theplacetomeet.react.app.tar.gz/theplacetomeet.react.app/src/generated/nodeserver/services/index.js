const CateringService = require('./CateringService');
const CustomerService = require('./CustomerService');
const MeetingRoomService = require('./MeetingRoomService');

module.exports = {
  CateringService,
  CustomerService,
  MeetingRoomService,
};
