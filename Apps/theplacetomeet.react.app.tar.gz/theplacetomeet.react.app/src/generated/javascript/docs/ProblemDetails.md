# ThePlaceToMeetWebApi.ProblemDetails

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**status** | **Number** |  | [optional] 
**detail** | **String** |  | [optional] 
**instance** | **String** |  | [optional] 


