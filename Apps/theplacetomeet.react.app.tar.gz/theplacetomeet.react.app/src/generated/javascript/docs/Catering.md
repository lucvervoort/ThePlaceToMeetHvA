# ThePlaceToMeetWebApi.Catering

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**titel** | **String** |  | [optional] 
**beschrijving** | **String** |  | [optional] 
**prijsPerPersoon** | **Number** |  | [optional] 


