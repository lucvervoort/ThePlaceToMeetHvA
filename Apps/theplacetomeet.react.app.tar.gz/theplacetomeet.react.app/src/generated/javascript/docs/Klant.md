# ThePlaceToMeetWebApi.Klant

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**email** | **String** |  | [optional] 
**naam** | **String** |  | [optional] 
**voornaam** | **String** |  | [optional] 
**gsm** | **String** |  | [optional] 
**bedrijf** | **String** |  | [optional] 
**reservaties** | [**[Reservatie]**](Reservatie.md) |  | [optional] [readonly] 


