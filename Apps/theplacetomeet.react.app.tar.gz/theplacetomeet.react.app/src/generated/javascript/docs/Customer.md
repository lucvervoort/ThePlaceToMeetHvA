# ThePlaceToMeetWebApi.Customer

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**email** | **String** |  | [optional] 
**lastName** | **String** |  | [optional] 
**firstName** | **String** |  | [optional] 
**mobile** | **String** |  | [optional] 
**company** | **String** |  | [optional] 
**reservations** | [**[Reservation]**](Reservation.md) |  | [optional] [readonly] 


