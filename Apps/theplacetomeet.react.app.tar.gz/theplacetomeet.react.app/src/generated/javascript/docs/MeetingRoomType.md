# ThePlaceToMeetWebApi.MeetingRoomType

## Enum


* `0` (value: `0`)

* `1` (value: `1`)

* `2` (value: `2`)


