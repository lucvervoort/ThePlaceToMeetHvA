# ThePlaceToMeetWebApi.Korting

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**percentage** | **Number** |  | [optional] 
**minimumAantalReservatiesInJaar** | **Number** |  | [optional] 


