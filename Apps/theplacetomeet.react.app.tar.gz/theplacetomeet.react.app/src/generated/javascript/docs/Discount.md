# ThePlaceToMeetWebApi.Discount

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**percentage** | **Number** |  | [optional] 
**minimumReservationsInAYear** | **Number** |  | [optional] 


