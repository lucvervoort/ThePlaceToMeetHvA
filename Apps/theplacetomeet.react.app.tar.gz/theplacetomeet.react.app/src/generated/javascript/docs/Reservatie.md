# ThePlaceToMeetWebApi.Reservatie

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**aantalPersonen** | **Number** |  | [optional] 
**dag** | **Date** |  | [optional] 
**beginUur** | **Number** |  | [optional] 
**duurInUren** | **Number** |  | [optional] 
**tot** | **Number** |  | [optional] [readonly] 
**prijsPerUur** | **Number** |  | [optional] 
**prijsPerPersoonStandaardCatering** | **Number** |  | [optional] 
**prijsPerPersoonCatering** | **Number** |  | [optional] 
**catering** | [**Catering**](Catering.md) |  | [optional] 
**korting** | [**Korting**](Korting.md) |  | [optional] 
**vergaderruimte** | [**Vergaderruimte**](Vergaderruimte.md) |  | [optional] 


