# ThePlaceToMeetWebApi.MeetingRoom

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**naam** | **String** |  | [optional] 
**vergaderruimteType** | [**MeetingRoomType**](MeetingRoomType.md) |  | [optional] 
**maximumAantalPersonen** | **Number** |  | [optional] 
**prijsPerUur** | **Number** |  | [optional] 
**prijsPerPersoonStandaardCatering** | **Number** |  | [optional] 
**reservaties** | [**[Reservation]**](Reservation.md) |  | [optional] [readonly] 


