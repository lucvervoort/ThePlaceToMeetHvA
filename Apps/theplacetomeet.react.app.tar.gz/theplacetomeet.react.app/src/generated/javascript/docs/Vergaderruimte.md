# ThePlaceToMeetWebApi.Vergaderruimte

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**naam** | **String** |  | [optional] 
**vergaderruimteType** | [**VergaderruimteType**](VergaderruimteType.md) |  | [optional] 
**maximumAantalPersonen** | **Number** |  | [optional] 
**prijsPerUur** | **Number** |  | [optional] 
**prijsPerPersoonStandaardCatering** | **Number** |  | [optional] 
**reservaties** | [**[Reservatie]**](Reservatie.md) |  | [optional] [readonly] 


