
# Org.OpenAPITools.Model.Customer

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** |  | [optional] 
**Email** | **string** |  | [optional] 
**LastName** | **string** |  | [optional] 
**FirstName** | **string** |  | [optional] 
**Mobile** | **string** |  | [optional] 
**Company** | **string** |  | [optional] 
**Reservations** | [**List&lt;Reservation&gt;**](Reservation.md) |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

