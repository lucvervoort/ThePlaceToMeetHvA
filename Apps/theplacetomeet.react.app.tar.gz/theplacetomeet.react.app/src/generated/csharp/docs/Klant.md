
# Org.OpenAPITools.Model.Klant

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int** |  | [optional] 
**Email** | **string** |  | [optional] 
**Naam** | **string** |  | [optional] 
**Voornaam** | **string** |  | [optional] 
**Gsm** | **string** |  | [optional] 
**Bedrijf** | **string** |  | [optional] 
**Reservaties** | [**List&lt;Reservatie&gt;**](Reservatie.md) |  | [optional] [readonly] 

[[Back to Model list]](../README.md#documentation-for-models)
[[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to README]](../README.md)

